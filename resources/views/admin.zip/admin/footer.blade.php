<!-- Javascript -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="{{ asset('adminassets/bundles/libscripts.bundle.js') }}"></script>
<script src="{{ asset('adminassets/bundles/vendorscripts.bundle.js') }}"></script>

<script src="{{ asset('adminassets/bundles/chartist.bundle.js') }}"></script>
<script src="{{ asset('adminassets/bundles/knob.bundle.js') }}"></script> <!-- Jquery Knob -->
<script src="{{ asset('adminassets/bundles/flotscripts.bundle.js') }}"></script> <!-- Flot Charts -->
<script src="{{ asset('adminassets/vendor/toastr/toastr.js') }}"></script>
<script src="{{ asset('adminassets/vendor/flot-charts/jquery.flot.selection.js') }}"></script>

<script src="{{ asset('adminassets/bundles/mainscripts.bundle.js') }}"></script>
<script src="{{ asset('adminassets/js/index.js') }}"></script>

</body>

</html>